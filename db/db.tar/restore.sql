--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.2
-- Dumped by pg_dump version 9.5.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.teams DROP CONSTRAINT teams_pkey;
ALTER TABLE ONLY public.schedules DROP CONSTRAINT schedules_pkey;
ALTER TABLE ONLY public.old_schedules DROP CONSTRAINT old_schedules_pkey;
ALTER TABLE ONLY public.off_rankings DROP CONSTRAINT off_rankings_pkey;
ALTER TABLE ONLY public.off_line_rankings DROP CONSTRAINT off_line_rankings_pkey;
ALTER TABLE ONLY public.def_rankings DROP CONSTRAINT def_rankings_pkey;
ALTER TABLE public.teams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.schedules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.old_schedules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.off_rankings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.off_line_rankings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.def_rankings ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.teams_id_seq;
DROP TABLE public.teams;
DROP SEQUENCE public.schedules_id_seq;
DROP TABLE public.schedules;
DROP SEQUENCE public.old_schedules_id_seq;
DROP TABLE public.old_schedules;
DROP SEQUENCE public.off_rankings_id_seq;
DROP TABLE public.off_rankings;
DROP SEQUENCE public.off_line_rankings_id_seq;
DROP TABLE public.off_line_rankings;
DROP SEQUENCE public.def_rankings_id_seq;
DROP TABLE public.def_rankings;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: def_rankings; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE def_rankings (
    id integer NOT NULL,
    acronym character varying(255),
    ranking integer,
    source character varying(255),
    year character varying(255)
);


ALTER TABLE def_rankings OWNER TO pavankatepalli;

--
-- Name: def_rankings_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE def_rankings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE def_rankings_id_seq OWNER TO pavankatepalli;

--
-- Name: def_rankings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE def_rankings_id_seq OWNED BY def_rankings.id;


--
-- Name: off_line_rankings; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE off_line_rankings (
    id integer NOT NULL,
    acronym character varying(255),
    ranking integer,
    source character varying(255),
    year character varying(255)
);


ALTER TABLE off_line_rankings OWNER TO pavankatepalli;

--
-- Name: off_line_rankings_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE off_line_rankings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE off_line_rankings_id_seq OWNER TO pavankatepalli;

--
-- Name: off_line_rankings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE off_line_rankings_id_seq OWNED BY off_line_rankings.id;


--
-- Name: off_rankings; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE off_rankings (
    id integer NOT NULL,
    acronym character varying(255),
    ranking integer,
    source character varying(255),
    year character varying(255)
);


ALTER TABLE off_rankings OWNER TO pavankatepalli;

--
-- Name: off_rankings_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE off_rankings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE off_rankings_id_seq OWNER TO pavankatepalli;

--
-- Name: off_rankings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE off_rankings_id_seq OWNED BY off_rankings.id;


--
-- Name: old_schedules; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE old_schedules (
    id integer NOT NULL,
    away character varying(255),
    away_score integer,
    home_score integer,
    home character varying(255),
    year character varying(255),
    week integer
);


ALTER TABLE old_schedules OWNER TO pavankatepalli;

--
-- Name: old_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE old_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE old_schedules_id_seq OWNER TO pavankatepalli;

--
-- Name: old_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE old_schedules_id_seq OWNED BY old_schedules.id;


--
-- Name: schedules; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE schedules (
    id integer NOT NULL,
    week integer,
    time_of_day character varying(255),
    away character varying(255),
    home character varying(255),
    year character varying(255)
);


ALTER TABLE schedules OWNER TO pavankatepalli;

--
-- Name: schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE schedules_id_seq OWNER TO pavankatepalli;

--
-- Name: schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE schedules_id_seq OWNED BY schedules.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE teams (
    id integer NOT NULL,
    acronym character varying(255),
    loc_team character varying(255),
    loc character varying(255),
    team character varying(255)
);


ALTER TABLE teams OWNER TO pavankatepalli;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE teams_id_seq OWNER TO pavankatepalli;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE teams_id_seq OWNED BY teams.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY def_rankings ALTER COLUMN id SET DEFAULT nextval('def_rankings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY off_line_rankings ALTER COLUMN id SET DEFAULT nextval('off_line_rankings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY off_rankings ALTER COLUMN id SET DEFAULT nextval('off_rankings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY old_schedules ALTER COLUMN id SET DEFAULT nextval('old_schedules_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY schedules ALTER COLUMN id SET DEFAULT nextval('schedules_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY teams ALTER COLUMN id SET DEFAULT nextval('teams_id_seq'::regclass);


--
-- Data for Name: def_rankings; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY def_rankings (id, acronym, ranking, source, year) FROM stdin;
\.
COPY def_rankings (id, acronym, ranking, source, year) FROM '$$PATH$$/2418.dat';

--
-- Name: def_rankings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('def_rankings_id_seq', 32, true);


--
-- Data for Name: off_line_rankings; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY off_line_rankings (id, acronym, ranking, source, year) FROM stdin;
\.
COPY off_line_rankings (id, acronym, ranking, source, year) FROM '$$PATH$$/2420.dat';

--
-- Name: off_line_rankings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('off_line_rankings_id_seq', 32, true);


--
-- Data for Name: off_rankings; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY off_rankings (id, acronym, ranking, source, year) FROM stdin;
\.
COPY off_rankings (id, acronym, ranking, source, year) FROM '$$PATH$$/2416.dat';

--
-- Name: off_rankings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('off_rankings_id_seq', 32, true);


--
-- Data for Name: old_schedules; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY old_schedules (id, away, away_score, home_score, home, year, week) FROM stdin;
\.
COPY old_schedules (id, away, away_score, home_score, home, year, week) FROM '$$PATH$$/2424.dat';

--
-- Name: old_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('old_schedules_id_seq', 4824, true);


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY schedules (id, week, time_of_day, away, home, year) FROM stdin;
\.
COPY schedules (id, week, time_of_day, away, home, year) FROM '$$PATH$$/2422.dat';

--
-- Name: schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('schedules_id_seq', 256, true);


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY teams (id, acronym, loc_team, loc, team) FROM stdin;
\.
COPY teams (id, acronym, loc_team, loc, team) FROM '$$PATH$$/2426.dat';

--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('teams_id_seq', 35, true);


--
-- Name: def_rankings_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY def_rankings
    ADD CONSTRAINT def_rankings_pkey PRIMARY KEY (id);


--
-- Name: off_line_rankings_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY off_line_rankings
    ADD CONSTRAINT off_line_rankings_pkey PRIMARY KEY (id);


--
-- Name: off_rankings_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY off_rankings
    ADD CONSTRAINT off_rankings_pkey PRIMARY KEY (id);


--
-- Name: old_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY old_schedules
    ADD CONSTRAINT old_schedules_pkey PRIMARY KEY (id);


--
-- Name: schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: teams_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

