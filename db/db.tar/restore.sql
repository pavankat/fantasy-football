--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.2
-- Dumped by pg_dump version 9.5.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.teams DROP CONSTRAINT teams_pkey;
ALTER TABLE ONLY public.schedules DROP CONSTRAINT schedules_pkey;
ALTER TABLE ONLY public.old_schedules DROP CONSTRAINT old_schedules_pkey;
ALTER TABLE ONLY public.off_rankings DROP CONSTRAINT off_rankings_pkey;
ALTER TABLE ONLY public.off_line_rankings DROP CONSTRAINT off_line_rankings_pkey;
ALTER TABLE ONLY public.drafts DROP CONSTRAINT drafts_pkey;
ALTER TABLE ONLY public.def_rankings DROP CONSTRAINT def_rankings_pkey;
ALTER TABLE public.teams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.schedules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.old_schedules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.off_rankings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.off_line_rankings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.drafts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.def_rankings ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.teams_id_seq;
DROP SEQUENCE public.schedules_id_seq;
DROP VIEW public.sched_plus_rankings_transforms;
DROP VIEW public.sched_plus_rankings;
DROP TABLE public.teams;
DROP TABLE public.schedules;
DROP SEQUENCE public.old_schedules_id_seq;
DROP TABLE public.old_schedules;
DROP SEQUENCE public.off_rankings_id_seq;
DROP TABLE public.off_rankings;
DROP SEQUENCE public.off_line_rankings_id_seq;
DROP TABLE public.off_line_rankings;
DROP SEQUENCE public.drafts_id_seq;
DROP TABLE public.drafts;
DROP SEQUENCE public.def_rankings_id_seq;
DROP TABLE public.def_rankings;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: def_rankings; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE def_rankings (
    id integer NOT NULL,
    acronym character varying(255),
    ranking integer,
    source character varying(255),
    year character varying(255)
);


ALTER TABLE def_rankings OWNER TO pavankatepalli;

--
-- Name: def_rankings_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE def_rankings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE def_rankings_id_seq OWNER TO pavankatepalli;

--
-- Name: def_rankings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE def_rankings_id_seq OWNED BY def_rankings.id;


--
-- Name: drafts; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE drafts (
    id integer NOT NULL,
    round integer,
    place_in_round integer,
    player character varying(255),
    team character varying(255),
    "position" character varying(255),
    mock boolean DEFAULT false,
    website character varying(255),
    typ character varying(255),
    dat date
);


ALTER TABLE drafts OWNER TO pavankatepalli;

--
-- Name: drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE drafts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE drafts_id_seq OWNER TO pavankatepalli;

--
-- Name: drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE drafts_id_seq OWNED BY drafts.id;


--
-- Name: off_line_rankings; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE off_line_rankings (
    id integer NOT NULL,
    acronym character varying(255),
    ranking integer,
    source character varying(255),
    year character varying(255)
);


ALTER TABLE off_line_rankings OWNER TO pavankatepalli;

--
-- Name: off_line_rankings_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE off_line_rankings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE off_line_rankings_id_seq OWNER TO pavankatepalli;

--
-- Name: off_line_rankings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE off_line_rankings_id_seq OWNED BY off_line_rankings.id;


--
-- Name: off_rankings; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE off_rankings (
    id integer NOT NULL,
    acronym character varying(255),
    ranking integer,
    source character varying(255),
    year character varying(255)
);


ALTER TABLE off_rankings OWNER TO pavankatepalli;

--
-- Name: off_rankings_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE off_rankings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE off_rankings_id_seq OWNER TO pavankatepalli;

--
-- Name: off_rankings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE off_rankings_id_seq OWNED BY off_rankings.id;


--
-- Name: old_schedules; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE old_schedules (
    id integer NOT NULL,
    away character varying(255),
    away_score integer,
    home_score integer,
    home character varying(255),
    year character varying(255),
    week integer
);


ALTER TABLE old_schedules OWNER TO pavankatepalli;

--
-- Name: old_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE old_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE old_schedules_id_seq OWNER TO pavankatepalli;

--
-- Name: old_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE old_schedules_id_seq OWNED BY old_schedules.id;


--
-- Name: schedules; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE schedules (
    id integer NOT NULL,
    week integer,
    time_of_day character varying(255),
    away character varying(255),
    home character varying(255),
    year character varying(255)
);


ALTER TABLE schedules OWNER TO pavankatepalli;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: pavankatepalli
--

CREATE TABLE teams (
    id integer NOT NULL,
    acronym character varying(255),
    loc_team character varying(255),
    loc character varying(255),
    team character varying(255)
);


ALTER TABLE teams OWNER TO pavankatepalli;

--
-- Name: sched_plus_rankings; Type: VIEW; Schema: public; Owner: pavankatepalli
--

CREATE VIEW sched_plus_rankings AS
 WITH sched_def_rankings AS (
         SELECT s.week,
            s.away,
            away_teams.acronym AS away_acr,
            s.home,
            home_teams.acronym AS home_acr,
            away_defs.ranking AS away_def_ranking,
            home_defs.ranking AS home_def_ranking
           FROM ((((schedules s
             LEFT JOIN teams away_teams ON (((s.away)::text = (away_teams.team)::text)))
             RIGHT JOIN def_rankings away_defs ON (((away_defs.acronym)::text = (away_teams.acronym)::text)))
             LEFT JOIN teams home_teams ON (((s.home)::text = (home_teams.team)::text)))
             RIGHT JOIN def_rankings home_defs ON (((home_defs.acronym)::text = (home_teams.acronym)::text)))
          ORDER BY s.week, home_teams.acronym
        ), sched_def_oline_rankings AS (
         SELECT sdr.week,
            sdr.away,
            sdr.away_acr,
            sdr.home,
            sdr.home_acr,
            sdr.away_def_ranking,
            sdr.home_def_ranking,
            home_ors.ranking AS home_off_line_ranking,
            away_ors.ranking AS away_off_line_ranking
           FROM ((sched_def_rankings sdr
             LEFT JOIN off_line_rankings home_ors ON (((home_ors.acronym)::text = (sdr.home_acr)::text)))
             LEFT JOIN off_line_rankings away_ors ON (((away_ors.acronym)::text = (sdr.away_acr)::text)))
        ), sched_def_oline_off_rankings AS (
         SELECT sdrolr.week,
            sdrolr.away,
            sdrolr.away_acr,
            sdrolr.home,
            sdrolr.home_acr,
            sdrolr.away_def_ranking,
            sdrolr.home_def_ranking,
            sdrolr.home_off_line_ranking,
            sdrolr.away_off_line_ranking,
            home_ors.ranking AS home_off_ranking,
            away_ors.ranking AS away_off_ranking
           FROM ((sched_def_oline_rankings sdrolr
             LEFT JOIN off_rankings home_ors ON (((home_ors.acronym)::text = (sdrolr.home_acr)::text)))
             LEFT JOIN off_rankings away_ors ON (((away_ors.acronym)::text = (sdrolr.away_acr)::text)))
        )
 SELECT sched_def_oline_off_rankings.week,
    sched_def_oline_off_rankings.away,
    sched_def_oline_off_rankings.away_acr,
    sched_def_oline_off_rankings.home,
    sched_def_oline_off_rankings.home_acr,
    sched_def_oline_off_rankings.away_def_ranking,
    sched_def_oline_off_rankings.home_def_ranking,
    sched_def_oline_off_rankings.home_off_line_ranking,
    sched_def_oline_off_rankings.away_off_line_ranking,
    sched_def_oline_off_rankings.home_off_ranking,
    sched_def_oline_off_rankings.away_off_ranking
   FROM sched_def_oline_off_rankings;


ALTER TABLE sched_plus_rankings OWNER TO pavankatepalli;

--
-- Name: sched_plus_rankings_transforms; Type: VIEW; Schema: public; Owner: pavankatepalli
--

CREATE VIEW sched_plus_rankings_transforms AS
 SELECT ((0.60 * ((((+ 0.5) * (((32 - ev.away_def_ranking) + 1))::numeric) + (0.25 * (ev.away_off_line_ranking)::numeric)) + (0.25 * (ev.away_off_ranking)::numeric))) + (0.40 * (((32 - ev.home_def_ranking) + 1))::numeric)) AS away_wr_ranking,
    ((0.60 * ((((+ 0.5) * (((32 - ev.home_def_ranking) + 1))::numeric) + (0.25 * (ev.home_off_line_ranking)::numeric)) + (0.25 * (ev.home_off_ranking)::numeric))) + (0.40 * (((32 - ev.away_def_ranking) + 1))::numeric)) AS home_wr_ranking,
    (((0.45 * ((0.75 * (ev.away_off_line_ranking)::numeric) + (0.25 * (ev.away_def_ranking)::numeric))) + (0.20 * (ev.away_off_ranking)::numeric)) + (0.35 * (ev.home_def_ranking)::numeric)) AS away_rb_ranking,
    (((0.45 * ((0.75 * (ev.home_off_line_ranking)::numeric) + (0.25 * (ev.home_def_ranking)::numeric))) + (0.20 * (ev.home_off_ranking)::numeric)) + (0.35 * (ev.away_def_ranking)::numeric)) AS home_rb_ranking,
    ((((0.4 * (((32 - ev.away_off_line_ranking) + 1))::numeric) + (0.2 * (ev.away_off_ranking)::numeric)) + (0.2 * (ev.away_def_ranking)::numeric)) + (0.2 * (ev.home_def_ranking)::numeric)) AS away_kicker_ranking,
    ((((0.4 * (((32 - ev.home_off_line_ranking) + 1))::numeric) + (0.2 * (ev.home_off_ranking)::numeric)) + (0.2 * (ev.home_def_ranking)::numeric)) + (0.2 * (ev.away_def_ranking)::numeric)) AS home_kicker_ranking,
    (((0.4 * (((32 - ev.home_off_ranking) + 1))::numeric) + (0.2 * (ev.away_def_ranking)::numeric)) + (0.4 * (((32 - ev.home_off_line_ranking) + 1))::numeric)) AS away_defence_ranking,
    (((0.4 * (((32 - ev.away_off_ranking) + 1))::numeric) + (0.2 * (ev.home_def_ranking)::numeric)) + (0.4 * (((32 - ev.away_off_line_ranking) + 1))::numeric)) AS home_defence_ranking,
    ev.week,
    ev.away,
    ev.away_acr,
    ev.home,
    ev.home_acr,
    ev.away_def_ranking,
    ev.home_def_ranking,
    ev.home_off_line_ranking,
    ev.away_off_line_ranking,
    ev.home_off_ranking,
    ev.away_off_ranking
   FROM sched_plus_rankings ev
  ORDER BY ev.week;


ALTER TABLE sched_plus_rankings_transforms OWNER TO pavankatepalli;

--
-- Name: schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE schedules_id_seq OWNER TO pavankatepalli;

--
-- Name: schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE schedules_id_seq OWNED BY schedules.id;


--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: pavankatepalli
--

CREATE SEQUENCE teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE teams_id_seq OWNER TO pavankatepalli;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pavankatepalli
--

ALTER SEQUENCE teams_id_seq OWNED BY teams.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY def_rankings ALTER COLUMN id SET DEFAULT nextval('def_rankings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY drafts ALTER COLUMN id SET DEFAULT nextval('drafts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY off_line_rankings ALTER COLUMN id SET DEFAULT nextval('off_line_rankings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY off_rankings ALTER COLUMN id SET DEFAULT nextval('off_rankings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY old_schedules ALTER COLUMN id SET DEFAULT nextval('old_schedules_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY schedules ALTER COLUMN id SET DEFAULT nextval('schedules_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY teams ALTER COLUMN id SET DEFAULT nextval('teams_id_seq'::regclass);


--
-- Data for Name: def_rankings; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY def_rankings (id, acronym, ranking, source, year) FROM stdin;
\.
COPY def_rankings (id, acronym, ranking, source, year) FROM '$$PATH$$/2439.dat';

--
-- Name: def_rankings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('def_rankings_id_seq', 32, true);


--
-- Data for Name: drafts; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY drafts (id, round, place_in_round, player, team, "position", mock, website, typ, dat) FROM stdin;
\.
COPY drafts (id, round, place_in_round, player, team, "position", mock, website, typ, dat) FROM '$$PATH$$/2449.dat';

--
-- Name: drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('drafts_id_seq', 150, true);


--
-- Data for Name: off_line_rankings; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY off_line_rankings (id, acronym, ranking, source, year) FROM stdin;
\.
COPY off_line_rankings (id, acronym, ranking, source, year) FROM '$$PATH$$/2441.dat';

--
-- Name: off_line_rankings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('off_line_rankings_id_seq', 32, true);


--
-- Data for Name: off_rankings; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY off_rankings (id, acronym, ranking, source, year) FROM stdin;
\.
COPY off_rankings (id, acronym, ranking, source, year) FROM '$$PATH$$/2437.dat';

--
-- Name: off_rankings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('off_rankings_id_seq', 32, true);


--
-- Data for Name: old_schedules; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY old_schedules (id, away, away_score, home_score, home, year, week) FROM stdin;
\.
COPY old_schedules (id, away, away_score, home_score, home, year, week) FROM '$$PATH$$/2445.dat';

--
-- Name: old_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('old_schedules_id_seq', 4824, true);


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY schedules (id, week, time_of_day, away, home, year) FROM stdin;
\.
COPY schedules (id, week, time_of_day, away, home, year) FROM '$$PATH$$/2443.dat';

--
-- Name: schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('schedules_id_seq', 256, true);


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: pavankatepalli
--

COPY teams (id, acronym, loc_team, loc, team) FROM stdin;
\.
COPY teams (id, acronym, loc_team, loc, team) FROM '$$PATH$$/2447.dat';

--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pavankatepalli
--

SELECT pg_catalog.setval('teams_id_seq', 35, true);


--
-- Name: def_rankings_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY def_rankings
    ADD CONSTRAINT def_rankings_pkey PRIMARY KEY (id);


--
-- Name: drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY drafts
    ADD CONSTRAINT drafts_pkey PRIMARY KEY (id);


--
-- Name: off_line_rankings_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY off_line_rankings
    ADD CONSTRAINT off_line_rankings_pkey PRIMARY KEY (id);


--
-- Name: off_rankings_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY off_rankings
    ADD CONSTRAINT off_rankings_pkey PRIMARY KEY (id);


--
-- Name: old_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY old_schedules
    ADD CONSTRAINT old_schedules_pkey PRIMARY KEY (id);


--
-- Name: schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: teams_pkey; Type: CONSTRAINT; Schema: public; Owner: pavankatepalli
--

ALTER TABLE ONLY teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

